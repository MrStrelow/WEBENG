package at.ac.tuwien.big.we14.lab2.exception;

/**
 * The EmptyException is thrown if the a requested category or question is
 * already empty.
 */
public class EmptyException extends Exception {
	private static final long serialVersionUID = 1L;
}
