package models;

/**
 * Base entity for all JPA classes
 */
public class BaseEntity {

    protected Long id;

    public Long getId() {
        return id;
    }

}
